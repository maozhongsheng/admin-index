CREATE
MATERIALIZED
VIEW
tianzhuo_ad_data
.
ssp_cost_local_view
TO
tianzhuo_ad_data
.
ssp_cost_local
(
    `date` Date,
    `date_hour` String,
    `publish_id` String,
    `media_id` String,
    `pos_id` String,
    `dsp_id` String,
    `dsp_pos_id` String,
    `dsp_media_id` String,
    `slot_type` String,
    `pv_cost` Int64,
    `click_cost` Int64,
    `req` Int64,
    `fill` Int64,
    `pv` Int64,
    `click` Int64,
    `download_start` Int64,
    `download_end` Int64,
    `install_start` Int64,
    `install_end` Int64,
    `activation` Int64,
    `deeplink` Int64,
    `ideeplink` Int64,
    `video_start` Int64,
    `video_end` Int64
)
AS
SELECT CAST(date_time, 'Date')                    AS date,
       multiIf(toHour(date_time) < 10, concat('0', CAST(toHour(date_time), 'String')),
               CAST(toHour(date_time), 'String')) AS date_hour,
       publish_id,
       media_id,
       pos_id,
       dsp_id,
       dsp_pos_id,
       dsp_media_id,
       slot_type,
       pv_price                                   AS pv_cost,
       click_price                                AS click_cost,
       req,
       fill,
       pv,
       click,
       download_start,
       download_end,
       install_start,
       install_end,
       activation,
       deeplink,
       ideeplink,
       video_start,
       video_end
FROM tianzhuo_ad_data.ssp_ods_cost_local;

